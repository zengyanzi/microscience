=== Banner Upload ===
Contributors: vinoth06, buffercode
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7DHAEMST475BY
Tags: banner, widget, advertisement, ads, banner ads, widget ads, image ads, image widget, ads upload, upload advertisement, upload widget ads
Requires at least: 4.3
Tested up to: 4.7.3
Stable tag: 1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy way to display the different size of banner advertisements in WordPress using widgets

== Description ==
Easy way to display the different size of banner advertisements in WordPress using widgets

Through this plugin admin can,

* Upload the banner ads through widget.
* Specify the banner ads width and height size using px.
* Create multiple banner ads using widgets.
* Specific the link for that advertisement, so that when users click the banner, the link will be opened in new window.
* Add the custom title for their widget.

[For Support](https://buffercode.com/plugin/banner-upload-wordpress-plugin)

== Installation ==

1. Upload the "banner-upload" directory to the plugins directory.
2. Go to the plugins setting page and activate "Banner Upload"
3. Go to Appearance --> Widget --> Drag Banner Upload Widget to appropriate location
4. Add the custom title, upload the image, add the image size and URL link.
5. Do save.

== Changelog ==

= v 1.6 (2017-March-14) =

* Support 4.7.3

* Few bug fixes

= v 1.4(016-July-11) =

* Support 4.2.2

= 1.3 =

* Open banner link in new window or same window.

= 1.2.1 =

* Bug fixes - Image uploading issue.

= 1.2 =

* Major bug fixes
* Moved the setting to widget location. Now user can able to add multiple banners using widget

= 1.0 =
* Public release

== Screenshots ==
1. Banner Upload setting page widget
2. Banner upload 350x250 image ads output
3. Banner upload 728x90 image ads output