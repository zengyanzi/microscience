<?php

// All extensions placed within the extensions directory will be auto-loaded for your Redux instance.
Redux::setExtensions('evl_options', dirname(__FILE__) . '/extensions/');
